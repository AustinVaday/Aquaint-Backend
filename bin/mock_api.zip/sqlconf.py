# Configuration for SQL on RDS
endpoint = "aquaint-follows.cys9slsyuljx.us-east-1.rds.amazonaws.com"
port = 3306
username = "lambda"
dbname = "follows_db"
timeout = 10
